﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class interaksiVR : MonoBehaviour
{

    public int jarakRaycast = 20;
    private RaycastHit raycastHit;
    public float batasMinimSudut = 30.0f;
    public float kecepatan = 3.0f;
    public bool berjalan;
    private CharacterController cc;
    public Transform kamera;

    // Start is called before the first frame update
    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        cc = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        Ray ray = Camera.main.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0.5f));
        if (Physics.Raycast(ray, out raycastHit, jarakRaycast))
        {
            if (raycastHit.transform.CompareTag("Benda"))
            {
                Destroy(raycastHit.transform.gameObject); 
            }
        }

        if (kamera.eulerAngles.x > batasMinimSudut && kamera.eulerAngles.x < 90.0f)
        {
            berjalan = true;
        }
        else
        {
            berjalan = false;
        }

        if (berjalan) 
        {
            Vector3 maju = kamera.TransformDirection(Vector3.forward);
            cc.SimpleMove(maju * kecepatan);
        }
    }
}
